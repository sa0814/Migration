# frozen_string_literal: true

module Capybara::RackTest::Errors
  class StaleElementReferenceError < StandardError
  end
end
