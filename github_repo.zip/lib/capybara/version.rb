# frozen_string_literal: true

module Capybara
  VERSION = '3.38.0'
end
