**Note:** This is for issues with Capybara.  If you have a howto type question, please ask on the mailing list as requested in the README: http://groups.google.com/group/ruby-capybara

## Meta
Capybara Version:
<!-- 2.8.1? -->
Driver Information (and browser if relevant):
<!-- selenium-webdriver 2.53.4 with Firefox 47.0.1? capybara-webkit? Poltergeist? -->

## Expected Behavior

## Actual Behavior
<!-- include full stacktrace of any error -->

## Steps to reproduce
<!--
Please be sure to include the code that is creating the issue along with HTML the code is being run against
-->
